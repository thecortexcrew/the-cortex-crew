import { createSlice } from "@reduxjs/toolkit";

const profileSlice = createSlice({
  name: "profile",
  initialState: null,
  reducers: {
    addProfileData: (state, action) => action.payload,
    removeProfile: (state, action) =>null
  },
});

export const { addProfileData, removeProfile } = profileSlice.actions;

export default profileSlice.reducer;
