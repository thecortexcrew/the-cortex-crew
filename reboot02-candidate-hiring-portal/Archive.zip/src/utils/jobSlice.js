import { createSlice } from "@reduxjs/toolkit";

const jobSlice = createSlice({
  name: "job",
  initialState: null,
  reducers: {
    addJobPostings: (state, action) => action.payload,
  },
});

export const { addJobPostings } = jobSlice.actions;

export default jobSlice.reducer;
