import { configureStore } from "@reduxjs/toolkit";
import jobReducer from "./jobSlice";
import jobDescReducer from "./jobDescSlice";
import profileReducer from "./profileSlice";

const appStore = configureStore({
  reducer: {
     JobPostings: jobReducer,
     JobDescription: jobDescReducer,
     profile: profileReducer,
   },
    devTools: true,
});
export default appStore;
