import { createSlice } from "@reduxjs/toolkit";

const jobDescSlice = createSlice({
  name: "jobDesc",
  initialState: null,
  reducers: {
    addJobDescription: (state, action) => action.payload,
    clearJobDescription: () => null,
  },
});

export const { addJobDescription, clearJobDescription } = jobDescSlice.actions;

export default jobDescSlice.reducer;
