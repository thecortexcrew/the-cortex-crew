export function profilePayload(profile, jobDescriptionData, selectedFile) {
  let requestBody = {
    JobID: jobDescriptionData?.jobPostingInfo?.jobReqId || "",
    JobDescription:
      jobDescriptionData?.jobPostingInfo?.jobDescription || "Backend Developer",
    ApplicantId: profile?.ApplicantId || '',
    IdentificationID: profile.IdentificationID || '',
    Profile: profile.Profile || '',
  };
  console.log(requestBody);

  const formData = new FormData();
  formData.append("job", JSON.stringify(requestBody)); // append job object as JSON string
  formData.append("file", selectedFile); // append file
  console.log(formData);

  return formData;
}
