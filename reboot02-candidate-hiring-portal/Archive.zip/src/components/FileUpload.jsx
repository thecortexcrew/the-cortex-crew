import React, { useState, useRef, useEffect } from "react";
import classNames from "classnames";
import { removeProfile } from "../utils/profileSlice";
import { useDispatch, useSelector } from "react-redux";
import { useFile } from "./FileContext";

const MAX_FILE_SIZE_MB = 5;
const ALLOWED_TYPES = [
  "application/pdf", // .pdf
];

const FileUpload = ({ onUpload, isFileUploaded }) => {
   const profile = useSelector((state) => state?.profile);
  const dispatch = useDispatch();
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [error, setError] = useState("");
  const inputRef = useRef(null);
const {file,setFile} = useFile();
   useEffect(() => {
      if (!file) {
        setFile(null);
        setSelectedFile(null);
      }
    }, [file]);

  const validateFile = (file) => {
    if (!ALLOWED_TYPES.includes(file.type)) {
      return "Invalid file type. Only PDF allowed.";
    }
    if (file.size > MAX_FILE_SIZE_MB * 1024 * 1024) {
      return "File is too large. Max size is 5MB.";
    }
    return null;
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setError("");
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    const file = e.dataTransfer.files[0];
    if (file) {
      const errorMsg = validateFile(file);
      if (errorMsg) {
        setError(errorMsg);
        return;
      }
      setSelectedFile(file);
      setError("");
    }
  };

  const handleChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const errorMsg = validateFile(file);
      if (errorMsg) {
        setError(errorMsg);
        return;
      }
      setSelectedFile(file);
      setError("");
    }
  };

  const openFileDialog = () => {
    inputRef.current.click();
  };

  const handleUpload = () => {
    if (onUpload && selectedFile) {
      onUpload(selectedFile);
    }
  };

  const handleDelete = () => {
    setSelectedFile(null);
    dispatch(removeProfile());
    setError("");
  };

  return (
    <div className="">
      <p>
        If you have a CV that you wish to upload, save time on your application
        by uploading it here. You can check the information has been transposed
        accurately, as you work your way through your application.
      </p>

      <p className="my-4 text-xs text-gray-400">
        Upload only PDF file type.(5MB max)
      </p>

      {!selectedFile ? (
        <div className="">
          <div
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            onClick={openFileDialog}
            className={classNames(
              "flex flex-col justify-center h-full border-2 border-dashed rounded-xl p-8  text-center cursor-pointer transition-colors",
              {
                "border-blue-500 bg-blue-50": dragActive,
                "border-gray-300": !dragActive,
              }
            )}
          >
            <input
              type="file"
              ref={inputRef}
              style={{ display: "none" }}
              onChange={handleChange}
              accept=".pdf"
            />
            <div className="flex flex-col justify-center">
              <div className="mx-auto">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="56"
                  height="56"
                  class="wd-accent-arrow-up-circle wd-accent"
                  focusable="false"
                  role="presentation"
                  viewBox="0 0 56 56"
                >
                  <g fill="none" fill-rule="evenodd" class="wd-icon-container">
                    <circle
                      cx="28"
                      cy="28"
                      r="22"
                      fill="#FFF"
                      class="french-vanilla-100"
                    ></circle>
                    <path
                      fill="#005DBA"
                      fill-rule="nonzero"
                      d="M28 4c13.255 0 24 10.745 24 24S41.255 52 28 52 4 41.255 4 28 14.745 4 28 4zm0 2C15.85 6 6 15.85 6 28s9.85 22 22 22 22-9.85 22-22S40.15 6 28 6zm-.017 12a.48.48 0 0 1 .356.144l7.778 7.778a.506.506 0 0 1-.003.71l-.7.701a.495.495 0 0 1-.711.003L29 21.634V37.26c0 .273-.226.5-.505.5h-.99a.495.495 0 0 1-.505-.5V21.604l-5.732 5.732a.506.506 0 0 1-.71-.003l-.701-.7a.495.495 0 0 1-.003-.71l7.777-7.779a.498.498 0 0 1 .352-.144z"
                      class="color-500"
                    ></path>
                  </g>
                </svg>
              </div>
              <p className=" text-gray-700">Drop file here</p>
              <p>
                or
                <span className="font-bold text-green-700 underline">
                  {" "}
                  browse
                </span>
              </p>
            </div>
          </div>
          {error && (
            <div className="text-red-600 text-sm mt-2 text-center">{error}</div>
          )}
        </div>
      ) : (
        <div className="bg-white p-4  rounded-xl shadow-md border border-gray-200 flex flex-col gap-4">
          <div className="flex justify-between items-center">
            <div className="flex gap-2 items-center">
              <div className="flex flex-col justify-center items-center bg-gray-200 p-2">
                <svg
                  className=""
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  class="wd-icon-pdf wd-icon"
                  focusable="false"
                  role="presentation"
                  viewBox="0 0 24 24"
                >
                  <g class="wd-icon-container">
                    <path
                      d="M5.5 7a.5.5 0 0 0 .5-.5V4h12v2.5a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-4a.5.5 0 0 0-.5-.5h-15a.5.5 0 0 0-.5.5v4a.5.5 0 0 0 .5.5h1zM6 17.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v4a.5.5 0 0 0 .5.5h15a.5.5 0 0 0 .5-.5v-4a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5V20H6v-2.5zM4.74 13.168v2.198a.25.25 0 0 1-.25.25H3.25a.25.25 0 0 1-.25-.25V8.65a.25.25 0 0 1 .25-.25h2.63c.551 0 1.039.102 1.462.307.426.202.754.49.986.868.234.373.352.798.352 1.273 0 .704-.253 1.267-.759 1.69-.502.42-1.192.63-2.071.63H4.74zm0-1.343h1.14c.336 0 .593-.085.768-.253.178-.169.267-.406.267-.714 0-.337-.09-.606-.272-.808-.182-.201-.43-.304-.744-.307H4.74v2.082zM9.861 15.616a.25.25 0 0 1-.25-.25V8.65a.25.25 0 0 1 .25-.25h2.075c.637 0 1.21.145 1.72.436.508.288.905.696 1.189 1.224.287.526.433 1.115.436 1.77v.332c0 .66-.14 1.253-.421 1.779a3.06 3.06 0 0 1-1.18 1.229 3.346 3.346 0 0 1-1.695.446H9.861zm1.49-5.873v4.535h.605c.498 0 .882-.177 1.15-.53.267-.357.4-.886.4-1.586v-.313c0-.697-.133-1.222-.4-1.576-.268-.353-.658-.53-1.17-.53h-.585zM20.718 12.492a.25.25 0 0 1-.25.25h-2.555v2.624a.25.25 0 0 1-.25.25h-1.24a.25.25 0 0 1-.25-.25V8.65a.25.25 0 0 1 .25-.25h4.327a.25.25 0 0 1 .25.25v.843a.25.25 0 0 1-.25.25h-2.837v1.66h2.555a.25.25 0 0 1 .25.25v.838z"
                      class="wd-icon-fill"
                    ></path>
                  </g>
                </svg>
              </div>

              <p className="text-sm text-gray-700 mt-1">
                {selectedFile.name} ({(selectedFile.size / 1024).toFixed(1)} KB)
              </p>
            </div>
            <div className="cursor-pointer" onClick={handleDelete}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="size-6"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="m20.25 7.5-.625 10.632a2.25 2.25 0 0 1-2.247 2.118H6.622a2.25 2.25 0 0 1-2.247-2.118L3.75 7.5m6 4.125 2.25 2.25m0 0 2.25 2.25M12 13.875l2.25-2.25M12 13.875l-2.25 2.25M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125Z"
                />
              </svg>
            </div>
          </div>
          {isFileUploaded && (
                    <div className="flex justify-center items-center">
                      <span className="loading loading-bars loading-md"></span>
                    </div>
                  )}
          {!isFileUploaded && <div className="flex justify-center mt-6">
           
            <button
              onClick={handleUpload}
              disabled={profile !== null?'disabled':""}
              className="btn btn-outline btn-success"
            >
              Upload
            </button>
          </div>
          }
          
        </div>
      )}
    </div>
  );
};

export default FileUpload;
