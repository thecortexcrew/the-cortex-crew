import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { addJobPostings } from "../utils/jobSlice"; // Adjust the import path as necessary"
import { addJobDescription } from "../utils/jobDescSlice";

const JobPostings = ({handleJobPostingViewClick}) => {
  const dispatch = useDispatch();
  const jobPostings = useSelector((store) => store.JobPostings);
  const [selectedJob, setSelectedJob] = useState({})
  console.log("Job postings state:", jobPostings);

  const fetchJobPostings = () => {
    fetch("/src/mocks/jobSummary.json")
      .then((res) => res.json())
      .then((data) => dispatch(addJobPostings(data.jobPostings)))
      .catch((err) => console.error("Failed to fetch job postings:", err));
  };

  const handleJobClick = (job) => {
     fetch("/src/mocks/jobDetails.json")
      .then((res) => res.json())
      .then((data) => {
        const jobDetails = data.find(
          (jobDetails) => {
            return jobDetails.jobPostingInfo?.jobPostingId.slice(-6) === job.bulletFields[0]}
        );
        dispatch(addJobDescription(jobDetails));
        handleJobPostingViewClick();
        setSelectedJob(job)
      })
      .catch((err) => console.error("Failed to fetch job postings:", err));
  };

  React.useEffect(() => {
    fetchJobPostings();
   
  }, []);

  if (!jobPostings) {
    return <div>Loading job postings...</div>;
  }

  if (jobPostings.length === 0) {
    return <div>No job postings available.</div>;
  }

  return (
    <div>
      <ul className="bg-white my-6">
        {jobPostings.map((job, index) => (
          
          <li 
            className={`flex flex-col p-4 d border-b-1 border-gray-300 ${selectedJob ==job?'bg-gray-200 border-2 border-b-2 border-green-700':''}`}
            key={index}
        >
            <h3 className="font-semibold underline hover:bg-gray-200 cursor-pointer" onClick={() => handleJobClick(job)}>{job.title}</h3>
            <div className="flex items-center gap-2  my-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="size-6"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M15 10.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"
                />
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1 1 15 0Z"
                />
              </svg>

              {job.locationsText}
            </div>
            <div className="flex items-center gap-2  my-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="size-6"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"
                />
              </svg>

              {job.postedOn}
            </div>
            <ul className="flex gap-2 text-gray-500">
              <li>{job.bulletFields[0]}</li>
              <li>{job.bulletFields[1]}</li>
            </ul>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default JobPostings;
