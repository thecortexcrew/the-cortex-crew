import React from 'react'
import ReferalPortal from './ReferalPortal'
import Navbar from './Navbar'
import { Outlet } from 'react-router'

const Body = () => {
  return (
    <>
      <ReferalPortal />
        <Outlet/>
       
    </>
  )
}

export default Body