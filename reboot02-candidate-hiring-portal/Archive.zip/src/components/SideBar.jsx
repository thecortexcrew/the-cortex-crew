import React, { useState } from "react";
import HtmlInjector from "./HtmlInjector";

const SideBar = () => {
  const [showMore, setShowMore] = useState(false);
  return (
    <div className="font-semibold flex flex-col w-[336px] py-8 px-4 my-6 bg-white">
      <div>
        <p className="mb-4">About Us</p>
        <img
          src="https://lbg.wd3.myworkdayjobs.com/wday/cxs/lbg/Lloyds_Technology_Centre/sidebarimage/2ee844293e621014e1732e7281cf0000"
          alt="Logo"
        />
        <div className="italic">
          <p className="mt-4">
            We're Lloyds Technology Centre*, a tech and data company located in
            Hyderabad, India. We're part of Lloyds Banking Group, a leading
            provider of financial services in the UK and the UK's largest
            digital bank, with more than 27 million customers.
          </p>

          <div
            className={`transition-all duration-200 ${
              showMore ? "max-h-screen" : "max-h-0 overflow-hidden"
            }`}
          >
            <p className="mt-4">
              We're changing financial services, and we want you to join us.
              With market-leading people practices and great opportunities for
              career and skills growth, we are committed to creating an
              exceptional colleague experience that is welcoming for all. Join
              us! 
            </p>
            <p className="mt-4">
              *Lloyds Technology Centre does not offer financial services in
              India.
            </p>
          </div>
        </div>
<button
            className="btn btn-ghost mb-4 px-4 py-4 underline text-blue-500 hover:text-blue-700 flex items-center gap-2"
            onClick={() => setShowMore((prev) => !prev)}
          >
            {showMore ? (
              <>
                Read Less
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  class="wd-icon-chevron-up-small wd-icon"
                  focusable="false"
                  role="presentation"
                  viewBox="0 0 24 24"
                >
                  <g fill-rule="evenodd" class="wd-icon-container">
                    <path
                      d="M12 10.294L7.39 14.87a.44.44 0 0 1-.62 0l-.64-.635a.438.438 0 0 1 0-.624l5.523-5.482A.44.44 0 0 1 12 8a.44.44 0 0 1 .347.127l5.523 5.482.002.002a.44.44 0 0 1-.002.622l-.64.635a.44.44 0 0 1-.62 0L12 10.294z"
                      class="wd-icon-fill"
                    ></path>
                  </g>
                </svg>
              </>
            ) : (
              <>
                Read More
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  focusable="false"
                  role="presentation"
                  viewBox="0 0 24 24"
                >
                  <g fillRule="evenodd">
                    <path d="M12 13.703l4.61-4.575a.44.44 0 0 1 .62 0l.64.635a.44.44 0 0 1 .002.622l-.002.002-5.523 5.482a.44.44 0 0 1-.347.127.44.44 0 0 1-.347-.127L6.13 10.387a.44.44 0 0 1-.002-.622l.002-.002.64-.635a.44.44 0 0 1 .62 0L12 13.703z" />
                  </g>
                </svg>
              </>
            )}
          </button>

        <div className="mt-10">
          <p>Need Help?</p>
          <p className="mt-4">
            Should you wish to contact us for any reason, please email us at:{" "}
            <a href="mailto:indiarecruitment@lloydsbanking.com" target="_blank">
              <span className="text-blue-500 hover:underline">
                indiarecruitment@lloydsbanking.com
              </span>
            </a>
          </p>
        </div>

        <div className="mt-10">
          <p>Flexible Working Options</p>
          <p className="mt-4">
            For more Flexible Working Options please use the free text search,
            e.g. job sharing, variable hours, to identify relevant matches.
          </p>
        </div>
      </div>
    </div>
  );
};

export default SideBar;
