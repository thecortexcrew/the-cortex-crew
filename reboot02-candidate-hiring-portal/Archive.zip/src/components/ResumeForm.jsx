import React, { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { profilePayload } from "../mappers/ProfilePayload";
import axios from "axios";
import { useNavigate } from "react-router";
import { removeProfile } from "../utils/profileSlice";
import { useFile } from './FileContext';


export default function ProfileForm() {
  const dispatch = useDispatch();
  const profileFromStore = useSelector((state) => state.profile);
  const jobDescriptionData = useSelector((state) => state.JobDescription);
  // const selectedFile = useSelector((state) => state.file);
  const [profile, setProfile] = useState(null);
  const [showToastSuccess, setShowToastSuccess] = useState(false);
  const [showToastError, setShowToastError] = useState(false);
   const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const {file,setFile} = useFile();
    const formRef = useRef(null);


  useEffect(() => {
    if (profileFromStore) {
      setProfile(profileFromStore);
    }
    if (formRef.current) {
      formRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [profileFromStore]);

  const handleProfileChange = (field, value) => {
    setProfile({ ...profile, Profile: { ...profile.Profile, [field]: value } });
  };

  const handleEducationChange = (index, field, value) => {
    const updated = [...profile.Profile.Education];
    updated[index][field] = value;
    setProfile({ ...profile, Profile: { ...profile.Profile, Education: updated } });
  };

  const removeEducation = (index) => {
    const updated = profile.Profile.Education.filter((_, i) => i !== index);
    setProfile((prev) => ({
      ...prev,
      Profile: {
        ...prev.Profile,
        Education: updated,
      },
    }));
  };

  const addEducation = () => {
    if (profile?.Profile?.Education.length < 5) {
      setProfile((prev) => ({
        ...prev,
        Profile: {
          ...prev.Profile,
          Education: [
            ...prev.Profile.Education,
            { Degree: "", Duration: "", Ongoing: false, University: "" },
          ],
        },
      }));
    }
  };

  const handleWorkExpChange = (index, field, value) => {
    const updated = [...profile.Profile.WorkExp];
    updated[index][field] = value;
    const updatedProfile = { ...profile.Profile, WorkExp: updated };
    setProfile({ ...profile, Profile: updatedProfile });
  };

  const addWorkExp = () => {
    if (profile?.Profile.WorkExp.length < 5)
      setProfile((prev) => ({
        ...prev,
        Profile: {
          ...prev.Profile,
          WorkExp: [
            ...prev.Profile.WorkExp,
            {
              Company: "",
              Duration: "",
              Project: [
                {
                  Name: "",
                  Responsibilities: "",
                  Role: "",
                },
              ],
            },
          ],
        },
      }));
  };

  const removeWorkExp = (index) => {
    const updatedWorkExp = profile.Profile.WorkExp.filter(
      (_, i) => i !== index
    );
    setProfile((prev) => ({
      ...prev,
      Profile: {
        ...prev.Profile,
        WorkExp: updatedWorkExp,
      },
    }));
  };

  const handleFormSubmit = async (event) => {
    event.preventDefault();
    const mapProfileRequest = profilePayload(
      profile,
      jobDescriptionData,
      file
    );
    console.log(mapProfileRequest);

    try {
      setLoading(true);
        const response = await axios.post(
          "http://resumeassist.net/api/jobs",
          mapProfileRequest
      );
      console.log(response);
      setShowToastSuccess(true);
      setLoading(false);
      navigate('/formSubmitSuccess')
      // Optionally navigate after success
      // navigate("/");
    } catch (error) {
      setLoading(false);
      setShowToastError(true);
      await new Promise((resolve) => {
        setTimeout(() => {
          setShowToastError(false);
          resolve();
        }, 2000);
      });
      console.error("Error submitting profile", error);
      console.log(profile);
    }finally {
      // Reset the profile and file state after submission
     dispatch(removeProfile());
      setFile(null);
      setProfile(null);
    }

    console.log("profile submit", profile);
  };

  const removeProject = (exp,projIdx,idx) => {
    const updatedProjects = exp.Project.filter((_, i) => i !== projIdx);
    const updatedWorkExp = profile.Profile.WorkExp.map((w, wIdx) =>
      wIdx === idx ? { ...w, Project: updatedProjects } : w
    );
    setProfile((prev) => ({
      ...prev,
      Profile: {
        ...prev.Profile,
        WorkExp: updatedWorkExp,
      },
    }));
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <span className="loading loading-spinner loading-lg"></span>
      </div>
    );
  }

  if (!profile  || !profileFromStore) return;

  if (!profile?.Profile) return null;

  const { DateOfApplication, DateOfBirth, Gender, MobileNo, Name, EmailId, SkillSets } =
    profile?.Profile;

  return (
    <>
      <div className="mt-12">
        <h2 className="text-3xl mb-4 font-bold text-center">Profile</h2>
        <form ref={formRef} className=" space-y-4" onSubmit={handleFormSubmit}>
          {/* <p className="font-bold ">Profile </p> */}
          <div className="bg-white p-4 flex flex-col gap-4 border rounded-lg  border-gray-300">
            <p className="font-bold ">Profile Details</p>
            <div className=" grid grid-cols-1 md:grid-cols-2 gap-4">
              <fieldset className="fieldset">
                <legend className="fieldset-legend">Application ID</legend>
                <input
                  type="text"
                  placeholder="Application ID"
                  className="input input-bordered w-full"
                  value={profile.ApplicantId || ""}
                  disabled
                  required
                />
              </fieldset>
              {/* <fieldset class="fieldset">
                <legend class="fieldset-legend">Application ID</legend>
                <input
                  type="text"
                  placeholder="Application ID"
                  className="input input-bordered w-full"
                  value={profile.ApplicantId || ""}
                  onChange={(e) =>
                    handleProfileChange("ApplicationID", e.target.value)
                  }
                  required
                />
              </fieldset> */}

              <fieldset className="fieldset">
                <legend className="fieldset-legend">Date of Application</legend>
                <input
                  type="date"
                  placeholder="Date of Application"
                  className="input input-bordered w-full"
                  value={DateOfApplication || ""}
                  onChange={(e) =>
                    handleProfileChange("DateOfApplication", e.target.value)
                  }
                  required
                />
              </fieldset>

              <fieldset class="fieldset">
                <legend class="fieldset-legend">Date of Birth</legend>
                <input
                  type="date"
                  className="input input-bordered w-full"
                  value={DateOfBirth || ""}
                  onChange={(e) =>
                    handleProfileChange("DateOfBirth", e.target.value)
                  }
                  required
                />
              </fieldset>

              <fieldset class="fieldset">
                <legend class="fieldset-legend">Gender</legend>
                <select
                  className="select select-bordered w-full"
                  value={Gender || ""}
                  onChange={(e) =>
                    handleProfileChange("Gender", e.target.value)
                  }
                  required
                >
                  <option disabled value="">
                    Gender
                  </option>
                  <option>Female</option>
                  <option>Male</option>
                  <option>Other</option>
                </select>
              </fieldset>

              <fieldset class="fieldset">
                <legend class="fieldset-legend">Mobile No.</legend>
                <input
                  type="text"
                  placeholder="Mobile Number"
                  className="input input-bordered w-full"
                  value={MobileNo || ""}
                  onChange={(e) =>
                    handleProfileChange("MobileNo", e.target.value)
                  }
                  required
                />
              </fieldset>
              <fieldset class="fieldset">
                <legend class="fieldset-legend">Identification ID</legend>
                <input
                  type="text"
                  placeholder="Identification ID"
                  className="input input-bordered w-full"
                  value={profile.IdentificationID || ""}
                 disabled
                  required
                />
              </fieldset>
            </div>

            <fieldset class="fieldset">
              <legend class="fieldset-legend">Full Name</legend>
              <input
                type="text"
                placeholder="Full Name"
                className="input input-bordered w-full"
                value={Name || ""}
                onChange={(e) => handleProfileChange("Name", e.target.value)}
                required
              />
            </fieldset>

            <fieldset class="fieldset">
              <legend class="fieldset-legend">Email</legend>
              <input
                type="email"
                placeholder="Email"
                className="input input-bordered w-full"
                value={EmailId || ""}
                onChange={(e) => handleProfileChange("EmailId", e.target.value)}
                required
              />
            </fieldset>

            <fieldset class="fieldset">
              <legend class="fieldset-legend">Skills</legend>
              <textarea
                className="textarea textarea-bordered w-full"
                placeholder="Skill Sets"
                value={SkillSets || ""}
                onChange={(e) =>
                  handleProfileChange("SkillSets", e.target.value)
                }
                required
              ></textarea>
            </fieldset>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-2">Education</h2>
            {profile?.Profile?.Education.map((edu, idx) => (
              <div
                key={idx}
                className="mb-4 p-4 border rounded-lg bg-white border-gray-300"
              >
                <div className="flex justify-between mb-4">
                  <p className="font-bold">{`Education ${idx + 1}`}</p>
                {profile?.Profile?.Education.length>1  &&   <div
                    className="cursor-pointer"
                    onClick={() => removeEducation(idx)}
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                      strokeWidth={1.5}
                      stroke="currentColor"
                      className="size-6"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="m20.25 7.5-.625 10.632a2.25 2.25 0 0 1-2.247 2.118H6.622a2.25 2.25 0 0 1-2.247-2.118L3.75 7.5m6 4.125 2.25 2.25m0 0 2.25 2.25M12 13.875l2.25-2.25M12 13.875l-2.25 2.25M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125Z"
                      />
                    </svg>
                  </div>}
                </div>

                <fieldset class="fieldset">
                  <legend class="fieldset-legend">Degree</legend>
                  <input
                    type="text"
                    className="input input-bordered w-full mb-2"
                    placeholder="Degree"
                    value={edu.Degree}
                    onChange={(e) =>
                      handleEducationChange(idx, "Degree", e.target.value)
                    }
                    required
                  />
                </fieldset>

                <fieldset class="fieldset">
                  <legend class="fieldset-legend">Duration</legend>
                  <input
                    type="text"
                    className="input input-bordered w-full mb-2"
                    placeholder="Duration"
                    value={edu.Duration}
                    onChange={(e) =>
                      handleEducationChange(idx, "Duration", e.target.value)
                    }
                    required
                  />
                </fieldset>

                <fieldset class="fieldset">
                  <legend class="fieldset-legend">University</legend>
                  <input
                    type="text"
                    className="input input-bordered w-full"
                    placeholder="University"
                    value={edu.University}
                    onChange={(e) =>
                      handleEducationChange(idx, "University", e.target.value)
                    }
                    required
                  />
                </fieldset>
              </div>
            ))}

            <button
              type="button"
              onClick={addEducation}
              disabled={profile?.Profile?.Education.length >= 5}
              className="btn btn-sm btn-outline btn-primary"
            >
              + Add Education
            </button>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-2">Work Experience</h2>
            {profile?.Profile?.WorkExp.map((exp, idx) => (
              <div
                key={idx}
                className="mb-4 p-4 border rounded-lg bg-white border-gray-300"
              >
                <div className="flex justify-between mb-4">
                  <p className="font-bold">{`Work Experience ${idx + 1}`}</p>
                 {profile?.Profile?.WorkExp.length > 1 &&  <div
                    className="cursor-pointer"
                    onClick={() => removeWorkExp(idx)}
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                      strokeWidth={1.5}
                      stroke="currentColor"
                      className="size-6"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="m20.25 7.5-.625 10.632a2.25 2.25 0 0 1-2.247 2.118H6.622a2.25 2.25 0 0 1-2.247-2.118L3.75 7.5m6 4.125 2.25 2.25m0 0 2.25 2.25M12 13.875l2.25-2.25M12 13.875l-2.25 2.25M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125Z"
                      />
                    </svg>
                  </div>}
                </div>

                <fieldset class="fieldset">
                  <legend class="fieldset-legend">Company</legend>
                  <input
                    type="text"
                    className="input input-bordered w-full mb-2"
                    placeholder="Company"
                    value={exp.Company}
                    onChange={(e) =>
                      handleWorkExpChange(idx, "Company", e.target.value)
                    }
                    required
                  />
                </fieldset>

                <fieldset class="fieldset">
                  <legend class="fieldset-legend">Duration</legend>
                  <input
                    type="text"
                    className="input input-bordered w-full mb-2"
                    placeholder="Duration"
                    value={exp.Duration}
                    onChange={(e) =>
                      handleWorkExpChange(idx, "Duration", e.target.value)
                    }
                    required
                  />
                </fieldset>

                {/* Projects Section */}
                {exp.Project.map((proj, projIdx) => (
                  <div
                    key={projIdx}
                    className="mb-4 p-2 border rounded bg-gray-50"
                  >
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-semibold">{`Project ${
                        projIdx + 1
                      }`}</span>

                     

                      {exp.Project.length > 1 && (
                        <div
                        className="cursor-pointer"
                        onClick={() => removeProject(exp,projIdx,idx)}
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          fill="none"
                          viewBox="0 0 24 24"
                          strokeWidth={1.5}
                          stroke="currentColor"
                          className="size-6"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="m20.25 7.5-.625 10.632a2.25 2.25 0 0 1-2.247 2.118H6.622a2.25 2.25 0 0 1-2.247-2.118L3.75 7.5m6 4.125 2.25 2.25m0 0 2.25 2.25M12 13.875l2.25-2.25M12 13.875l-2.25 2.25M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125Z"
                          />
                        </svg>
                      </div>
                      )}
                    </div>
                    <fieldset className="fieldset">
                      <legend className="fieldset-legend">Project Name</legend>
                      <input
                        type="text"
                        className="input input-bordered w-full mb-2"
                        placeholder="Project Name"
                        value={proj.Name || ""}
                        onChange={(e) => {
                          const updatedProjects = exp.Project.map((p, pIdx) =>
                            pIdx === projIdx
                              ? { ...p, Name: e.target.value }
                              : p
                          );
                          const updatedWorkExp = profile.Profile.WorkExp.map(
                            (w, wIdx) =>
                              wIdx === idx
                                ? { ...w, Project: updatedProjects }
                                : w
                          );
                          setProfile((prev) => ({
                            ...prev,
                            Profile: {
                              ...prev.Profile,
                              WorkExp: updatedWorkExp,
                            },
                          }));
                        }}
                        required
                      />
                    </fieldset>
                    <fieldset className="fieldset">
                      <legend className="fieldset-legend">Role</legend>
                      <input
                        type="text"
                        className="input input-bordered w-full mb-2"
                        placeholder="Role"
                        value={proj.Role || ""}
                        onChange={(e) => {
                          const updatedProjects = exp.Project.map((p, pIdx) =>
                            pIdx === projIdx
                              ? { ...p, Role: e.target.value }
                              : p
                          );
                          const updatedWorkExp = profile.Profile.WorkExp.map(
                            (w, wIdx) =>
                              wIdx === idx
                                ? { ...w, Project: updatedProjects }
                                : w
                          );
                          setProfile((prev) => ({
                            ...prev,
                            Profile: {
                              ...prev.Profile,
                              WorkExp: updatedWorkExp,
                            },
                          }));
                        }}
                        required
                      />
                    </fieldset>
                    <fieldset className="fieldset">
                      <legend className="fieldset-legend">
                        Responsibilities
                      </legend>
                      <textarea
                        className="textarea textarea-bordered w-full"
                        placeholder="Responsibilities"
                        value={proj.Responsibilities || ""}
                        onChange={(e) => {
                          const updatedProjects = exp.Project.map((p, pIdx) =>
                            pIdx === projIdx
                              ? { ...p, Responsibilities: e.target.value }
                              : p
                          );
                          const updatedWorkExp = profile.Profile.WorkExp.map(
                            (w, wIdx) =>
                              wIdx === idx
                                ? { ...w, Project: updatedProjects }
                                : w
                          );
                          setProfile((prev) => ({
                            ...prev,
                            Profile: {
                              ...prev.Profile,
                              WorkExp: updatedWorkExp,
                            },
                          }));
                        }}
                        required
                      />
                    </fieldset>
                  </div>
                ))}
                <button
                  type="button"
                  className="btn btn-xs btn-outline btn-primary mb-2"
                  disabled={exp.Project.length >= 5}
                  onClick={() => {
                    const updatedProjects = [
                      ...exp.Project,
                      { Name: "", Responsibilities: "", Role: "" },
                    ];
                    const updatedWorkExp = profile.Profile.WorkExp.map(
                      (w, wIdx) =>
                        wIdx === idx ? { ...w, Project: updatedProjects } : w
                    );
                    setProfile((prev) => ({
                      ...prev,
                      Profile: {
                        ...prev.Profile,
                        WorkExp: updatedWorkExp,
                      },
                    }));
                  }}
                >
                  + Add Project
                </button>
              </div>
            ))}

            <button
              type="button"
              onClick={addWorkExp}
              disabled={profile?.Profile?.WorkExp.length >= 5}
              className="btn btn-sm btn-outline btn-primary"
            >
              + Add Work Experience
            </button>
          </div>

          <input
            type="text"
            placeholder="Years of Experience"
            className="input input-bordered w-full"
            value={profile?.Profile?.YearsOfExp || ""}
            onChange={(e) => handleProfileChange("YearsOfExp", e.target.value)}
            required
          />


          <button type="submit" className="bg-green-700 text-white hover:bg-white hover:text-green-700 px-4 py-2 rounded transition border-2 border-green-700 my-4 w-full">
            Submit
          </button>
        </form>
      </div>
      {showToastSuccess && (
        <div className="toast toast-top toast-end">
          <div className="alert alert-success">
            <span>Profile Submitted Successfully.!</span>
          </div>
        </div>
      )}
      {showToastError && (
        <div className="toast toast-top toast-end">
          <div className="alert alert-error">
            <span>Profile Submission failed. Please retry.!</span>
          </div>
        </div>
      )}
    </>
  );
}
