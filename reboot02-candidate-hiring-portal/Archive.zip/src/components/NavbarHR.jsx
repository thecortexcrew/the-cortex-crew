import React from "react";

const Navbar = () => {
  return (
    <>
    <div className="navbar bg-base-100 shadow-sm lloyds-color h-[88px]">
    <img src="/src/assets/lloydsLogo.png" className="w-40 ml-[24px]"  alt="photo" />
        </div>
    </>
    
  );
};

export default Navbar;
