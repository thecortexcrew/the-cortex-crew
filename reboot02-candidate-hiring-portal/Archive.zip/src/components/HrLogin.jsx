import React from 'react'
import { useNavigate } from 'react-router';



const HrLogin = () => {
    const navigate = useNavigate();
    const handleFormSubmit = (event) => {
        event.preventDefault(); 
        const email = event.target.email.value;
        const password = event.target.password.value;
        // Perform login logic here
        // On successful login, navigate to the HR dashboard
        navigate('/HrScreening');
    }
  return (
    <>
     <div className="navbar fixed top-0 left-0 w-full bg-base-100 shadow-sm lloyds-color h-[88px] z-50">
        <img
          src="src/assets/lloydsLogo.png"
          className="w-40 ml-[24px]"
          alt="photo"
        />
      </div>
        <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <div className="w-full max-w-sm p-8 bg-white rounded-lg shadow-md">
            <h2 className="mb-6 text-2xl font-bold text-center">LLOYDS HR Login</h2>
            <form onSubmit={handleFormSubmit}>
                <div className="mb-4">
                    <label className="block mb-2 text-sm font-medium" htmlFor="email">
                        Email
                    </label>
                    <input
                        id="email"
                        type="email"
                        placeholder="Enter your email"
                        className="input input-bordered w-full"
                        required
                    />
                </div>
                <div className="mb-6">
                    <label className="block mb-2 text-sm font-medium" htmlFor="password">
                        Password
                    </label>
                    <input
                        id="password"
                        type="password"
                        placeholder="Enter your password"
                        className="input input-bordered w-full"
                        required
                    />
                </div>
                <button type="submit" className="bg-green-700 text-white hover:bg-white hover:text-green-700 px-4 py-2 rounded transition border-2 border-green-700 my-4 w-full">
                    Login
                </button>
            </form>
        </div>
    </div>
      </>
  
  )
}

export default HrLogin