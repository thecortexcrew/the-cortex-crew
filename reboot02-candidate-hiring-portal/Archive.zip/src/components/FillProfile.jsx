import React, { useState } from "react";
import FileUpload from "./FileUpload";
import axios from "axios";
import ProfileForm from "./ResumeForm";
import { useDispatch } from "react-redux";
import { addProfileData } from "../utils/profileSlice";
import profileData from "../../src/mocks/resumeResponse.json/";
import {useFile} from "./FileContext";
const FillProfile = () => {
  const [isFileUploaded, setIsFileUploaded] = useState(false);
  const [showToastError, setShowToastError] = useState(false);
  const dispatch = useDispatch();
  const { setFile } = useFile();
  const handleFileUpload = async (selectedFile) => {
    console.log("Uploaded files:", selectedFile);
    if (!selectedFile) return;

    const formData = new FormData();
    formData.append("cv", selectedFile);
    let response = {};
    try {
      setIsFileUploaded(true);
      response = await axios.post(
        "http://resumeassist.net/upload",
        formData
      );

      setIsFileUploaded(false);
      console.log("Upload successful:", response.data);
      if(response?.data?.error){
        setShowToastError(true);
        await new Promise((resolve) => {  
          setTimeout(() => {
            setShowToastError(false);
            resolve();
          }, 2000);
        });
        return;
      }
      // Optional: show success state or reset form
    } catch (error) {
      setIsFileUploaded(false);
      console.error("Upload failed:", error);
       setShowToastError(true);
      await new Promise((resolve) => {
        setTimeout(() => {
          setShowToastError(false);
          resolve();
        }, 2000);
      });
      // Optional: show error message
    }
    dispatch(addProfileData(response.data));
     if (response?.data?.predictions && response.data.predictions.length > 0) {
      dispatch(addProfileData(response.data.predictions[0]));
    }
    // dispatch(addProfileData(profileData));
    // dispatch(setSelectedFile(formData));
    setFile(selectedFile);
  };

  return (
    <div className="flex flex-col mx-auto justify-center p-4 max-w-[704px] min-w-[304px] my-8">
      <h1 className="text-xl font-semibold mb-4">Upload Your Profile</h1>
      <div className="flex flex-col">
        <FileUpload
          isFileUploaded={isFileUploaded}
          onUpload={handleFileUpload}
        />

        <ProfileForm />
      </div>
       {showToastError && (
        <div className="toast toast-top toast-end">
          <div className="alert alert-error">
            <span>Profile Submission failed.!</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default FillProfile;
