import React from 'react'

const Footer = () => {
    /* Ensure the footer sticks to the bottom */
    
    return (
        <footer className="footer bg-gray-100 footer-center mt-8 p-4  text-base-content">
            <div>
                <p>© 2025 Lloys Technology Centre, All rights reserved.</p>
            </div>
        </footer>
    )
}

export default Footer
