import React, { useState } from 'react'
import JobPostings from './JobPostings'
import JobDescription from './JobDescription'
import SideBar from './SideBar'

const ReferalPortal = () => {
  const [showDesc, setShowDesc] = useState(false);
  return (
    <div className='flex gap-4 flex-wrap justify-center'>
      <div className='max-w-480'> <JobPostings handleJobPostingViewClick={() => setShowDesc(true)} /></div>
      <div> {showDesc && <JobDescription handleJobPostingViewClick={() => setShowDesc(false)} />} </div>
      <div> {!showDesc && <SideBar/>}</div>

    </div>
  )
}

export default ReferalPortal