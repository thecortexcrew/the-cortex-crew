import React from 'react'

const FormSubmitSuccessPage = () => {
  return (
    <>
    <div className='h-100 flex m-12 flex-col gap-8'>
       <p>Thank you for sharing your profile.</p>
       <p>Our recruitment teams will review your profile and be in touch with suitable vacancies.</p> 


    </div>
    </>
  )
}

export default FormSubmitSuccessPage