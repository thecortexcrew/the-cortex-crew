import React, { useEffect, useState } from "react";
import axios from "axios";
import { useLocation } from "react-router";


const HRPortalScreen = () => {
  const [applicants, setApplicants] = useState([]);
  const [loading, setLoading] = useState(false);
  const [fileLoading, setFileLoading] = useState(false);
  const [selectedFeedback, setSelectedFeedback] = useState(null);
  const [selectedName, setSelectedName] = useState(false);
  const [profileBtnDsbld, setProfileBtnDsbld] = useState({});
  const [currentPage, setCurrentPage] = useState(1);
  const applicantsPerPage = 10;

  const location = useLocation();
  const routeState = location.state;

  const openModal = (feedback, name) => {
    setSelectedFeedback(feedback);
    setSelectedName(name);
    document.getElementById("feedback_modal").showModal();
  };

  const openProfile = async (applicantId, identificationId,index) => {
       setProfileBtnDsbld((prev) => ({
        ...prev,
        [index]: true,
      }));
    try {
      const res = await axios.get(
        `http://resumeassist.net/view-candidate/download/${applicantId}_${identificationId}`,
        {
          responseType: "blob",
        }
      );
      const blob = new Blob([res.data], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      window.open(url, "_blank");
    } catch (error) {
       setFileLoading(true);
      console.error("Failed to fetch resume:", error);
    }finally {
         setProfileBtnDsbld((prev) => ({
        ...prev,
        [index]: false,
      }));
        await new Promise((resolve) => {  
          setTimeout(() => {
           setFileLoading(false);
            resolve();
          }, 2000);
        });
  };
  }
  const fetchApplicants = async () => {
    setLoading(true);
    try {
      const res = await axios.get(
        `http://resumeassist.net/view-candidate/load-candidate/${routeState?.jobReqId}/''`
      );
      setApplicants(res.data);

      // const response = await axios.get("/src/mocks/hrPortalMocks.json");
      // console.log("Job Summary:", response.data);
      // setApplicants(response.data);
    } catch (error) {
      console.error("Failed to fetch applicants:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchApplicants();
  }, []);

  const totalPages = Math.ceil(applicants.length / applicantsPerPage);
  const startIndex = (currentPage - 1) * applicantsPerPage;
  const currentApplicants = applicants.slice(startIndex, startIndex + applicantsPerPage);

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <span className="loading loading-spinner loading-lg"></span>
      </div>
    );
  }

  if (applicants.length === 0) {
    return <div className="min-h-screen flex">No candidate available.</div>;
  }

  return (
    <>
      <div className="min-h-screen p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {currentApplicants.map((applicant, index) => {
            const {
              Profile,
              CreatedAt,
              IdentificationID,
              JobID,
              Feedback,
              ApplicantId,
            } = applicant;

            return (
              <div className="card bg-base-100 shadow-xl" key={index}>
                <div className="card-body">
                  <h2 className="card-title">{Profile.Name}</h2>
                  <div className="flex gap-8">
                    <div>
                      <p><strong>Email:</strong> {Profile.EmailId}</p>
                      <p><strong>Mobile:</strong> {Profile.MobileNo}</p>
                      <p><strong>Date of Birth:</strong> {Profile.DateOfBirth}</p>
                      <p><strong>Years of Experience:</strong> {Profile.YearsOfExp}</p>
                    </div>
                    <div>
                      <p><strong>Job ID:</strong> {JobID}</p>
                      <p><strong>Applicant ID:</strong> {ApplicantId}</p>
                      <p><strong>Identification ID:</strong> {IdentificationID}</p>
                      <p><strong>Applied On:</strong> {new Date(CreatedAt).toLocaleString()}</p>
                    </div>
                  </div>
                  <div className="mt-4">
                    <p><strong>Skills:</strong> {Profile.SkillSets}</p>
                  </div>
                  <div className="card-actions justify-start mt-4">
                    <button
                      className="btn btn-success btn-sm"
                      onClick={() => openModal(Feedback, Profile?.Name)}
                    >
                      View Feedback
                    </button>
                    <button
                      disabled={profileBtnDsbld[index]}
                      className="btn btn-link btn-sm"
                      onClick={() => openProfile(ApplicantId, IdentificationID,index)}
                    >
                      View Profile
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center mt-8">
            <div className="join">
              {[...Array(totalPages)].map((_, index) => {
                const pageNum = index + 1;
                return (
                  <button
                    key={pageNum}
                    className={`join-item btn btn-sm ${
                      currentPage === pageNum ? "btn-active" : ""
                    }`}
                    onClick={() => setCurrentPage(pageNum)}
                  >
                    {pageNum}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      <dialog id="feedback_modal" className="modal">
        <div className="modal-box max-w-3xl">
          <h3 className="font-bold text-lg">
            Recruiter's Feedback for {selectedName}
          </h3>
          <p className="py-4 whitespace-pre-line text-sm">{selectedFeedback}</p>
          <div className="modal-action flex justify-center">
            <form method="dialog">
              <button className="btn btn-error">Close</button>
            </form>
          </div>
        </div>
      </dialog>
      
      {fileLoading && (
        <div className="toast toast-top toast-end">
          <div className="alert alert-error">
            <span>Profile not found.!</span>
          </div>
        </div>
      )}
    </>
  );
};

export default HRPortalScreen;
