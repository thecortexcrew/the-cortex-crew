import { useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import { Provider } from "react-redux";
import appStore from "./utils/appStore";
import { BrowserRouter, Route, Routes } from "react-router";
import Body from "./components/Body";
import FillProfile from "./components/FillProfile";
import ReferalPortal from "./components/ReferalPortal";
import Navbar from "./components/Navbar";
import NavbarHR from "./components/NavbarHR";
import FormSubmitSuccessPage from "./components/FormSubmitSuccessPage";
import { FileProvider } from "./components/FileContext";
import HRPortalScreen from "./components/HRPortalScreen";
import HrLogin from "./components/HrLogin";
import Footer from "./components/Footer";
function App() {
  return (
    <Provider store={appStore}>
      <FileProvider>

        <BrowserRouter basename="/">
          <Routes>
            <Route
              path="/hrLogin"
              element={
                <>
                  <NavbarHR />
                  <HrLogin />
                </>
              }
            />
            <Route
              path="/HrScreening"
              element={
                <>
                  <NavbarHR />
                  <Body />
                </>
              }
            />
            <Route
              path="/hrPortal/:jobReqId"
              element={
                <>
                  <NavbarHR />
                  <HRPortalScreen />
                </>
              }
            />
            <Route
              path="/"
              element={
                <>
                  <Navbar />
                  <Body />
                </>
              }
            />
            <Route
              path="/fillProfile"
              element={
                <>
                  <Navbar />
                  <FillProfile />
                </>
              }
            />
            <Route
              path="/formSubmitSuccess"
              element={
                <>
                  <Navbar />
                  <FormSubmitSuccessPage />
                </>
              }
            />
          </Routes>
          <Footer />
        </BrowserRouter>
      </FileProvider>
    </Provider>
  );
}

export default App;
